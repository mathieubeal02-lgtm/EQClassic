sub EVENT_SAY { 
if($text=~/are you jeb lumsed?/i){
quest::say("I don't know who you are! Stofo informs me of all those who are traveling this path. If you wish to travel this path. you MUST first do his bidding. Only then will I consider helping you.");
}
if($text=~/I need a sack./i){
quest::say("I don't know who you are! Stofo informs me of all those who are traveling this path. If you wish to travel this path. you MUST first do his bidding. Only then will I consider helping you.");
}
if($text=~/what serpent?/i){
quest::say("The first truly powerful enchanter. Krilan Pedin. crafted the Serpent years ago. He trained his students to carry on the trade in a five-step process.  Each student then became a master and chose one of their own students to pass the legacy on to. Four others and I. myself. are current practitioners of the crafting.");
}
if($text=~/who is Polzin?/i){
quest::say("Master of the Phantasms - he is the last one you will seek out.  Hmm...Polzin is native to Erudin. however. after the incident near Paineel. no one has heard from him. I hope that he is well."); }
}
sub EVENT_ITEM { 
if($itemcount{10604} == 1){
quest::say("There is no need for you to show me the seal. You must show the other masters this seal.");
quest::summonitem("10604");
}
if($itemcount{10639} == 1){
quest::say("The path you have taken was long and hard. Now you are worthy to bear the Serpent.  Use it well.");
quest::summonitem("10650"); }
}
#END of FILE Zone:burningwood  ID:87102 -- a_Sarnak_imitator 

